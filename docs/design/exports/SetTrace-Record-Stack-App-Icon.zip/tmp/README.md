# SetTraceRecordStack

Generated from `D:\000_MyLibrary\100_code\110_Project\5_SetTrace\docs\design\app-icon-record-stack\tmp\work\spec.json`.

- Use `app-icon-record-stack.preview.svg` and `app-icon-record-stack.preview.png` for rounded local review.
- Use `app-icon-record-stack.svg` and `app-icon-record-stack.png` for an unrounded source/app canvas.
- Generic source assets can be adapted to a requested platform after review.

