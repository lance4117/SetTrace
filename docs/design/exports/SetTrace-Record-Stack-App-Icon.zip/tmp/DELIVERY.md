# SetTrace App Icon · 错位训练记录

当前选定方向：**B1 · 稍薄调整版**。用户在对比原始方案、三个 B 方向变体及厚度调整后，明确选择了这张图并授权制作正式 App Icon。

- [图标素材目录](app-icon-record-stack/)
- [下载 ZIP 图标包](exports/SetTrace-Record-Stack-App-Icon.zip)
- [1024px PNG](app-icon-record-stack/app-icon-record-stack.png)
- [可编辑 SVG](app-icon-record-stack/app-icon-record-stack.svg)
- [圆角预览](app-icon-record-stack/app-icon-record-stack.preview.png)
- [用户确认的原始草图](app-icon-record-stack/app-icon-record-stack.origin.png)

## 设计与来源

三张宽厚圆角卡片从右上向左下错位叠放，以薄荷绿、浅青绿、冷白表达先后记录与当前记录。延续 App 内部 Focus A 的克制、清晰、专注和青绿体系。实际色值从用户确认的生成稿干净区域取中位数，避免使用此前提示词中的理想数值代替已选画面。

| 层 | 色值 | 1024px 画布位置 |
| --- | --- | --- |
| 背景 | `#028170` | 全画布正方形 |
| 后方记录 | `#56DBB8` | x=331，y=235 |
| 中间记录 | `#AFE7D9` | x=241，y=387 |
| 当前记录 | `#F6F7F9` | x=148，y=536 |

三张卡片统一宽 548px、高 206px、圆角半径 54px。它们依据确认稿的实际像素边界重建，保留确认稿的横向比例、错位节奏和位置；只将生成图中不足 1% 的同类形状尺寸差异整理为一致的几何，并去除细微纹理。实际采用的几何以 `tmp/work/spec.json` 为准，不沿用早期概念提示词中未准确呈现在生成图里的尺寸。

来源是本次对话中生成、用户选定的 B1 稍薄草图。原始 PNG 完整保留为唯一 `.origin.png`。未使用旧哑铃图标或第三方标志。

## 交付内容

- `app-icon-record-stack.svg` / `.png`：1024×1024 正方形源画布，PNG 全不透明，未预制平台圆角。
- `app-icon-record-stack.preview.svg` / `.preview.png`：圆角展示预览；预览蒙版不进入正方形源文件或图层。
- `layers/`：一个背景和三个独立、透明背景的卡片 SVG；按从后到前排序，可单独编辑位置、颜色和圆角。
- `tmp/work/spec.json`：完整内联矢量规格，可通过 app-icon-gen 的 `author-icon --spec <绝对路径> --out <交付目录绝对路径>` 重建。
- `tmp/reports/`：结构核验、前景几何审计、参考并排／叠图／差分和独立视觉复核。
- `tmp/work/small-size-review.png`：同一图标在浅深背景上的实际尺寸检查，不表示额外深色主题变体。

## 核验与边界

图标直接生成至本交付目录。参考图仅做 1254px → 1024px 等比缩放与预览圆角归一化，没有改色、改变主体位置或用重新绘制的图代替原参考。全局平均 RGB 差异约 0.9938/255；视觉差分门槛、局部采样及结构检查通过。前景的三个圆角路径均通过几何审计，未使用 PNG 回退或外部图片嵌入。

已检查 1024px 正方形源图、圆角预览、独立图层以及 128／64／48／32／24px 缩略图。独立复核结论见 `tmp/reports/visual-review.json`。与原稿不逐像素相同的部分是纹理清理及细小的同类几何统一。

此交付为可复用的通用图标源素材包。尚未执行 Android 自适应／单色启动器资源导出、各密度 mipmap 生成、应用接入或设备启动器验收；也未请求 Apple Icon Composer 包。原来的应用资源保持现状。早期哑铃素材包保留作历史候选，本目录为本次选定设计。

ZIP 包包含源图、原稿、分层 SVG、生成规格和检查证据，不包含依赖运行时或未选择的候选草图。
