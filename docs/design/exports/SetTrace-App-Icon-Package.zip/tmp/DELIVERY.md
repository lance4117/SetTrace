# SetTrace App Icon Package · Focus A

2026-10-15。使用项目的 `app-icon-gen` 技能制作，交付目录为 [`app-icon-package/`](app-icon-package/)，压缩包为 [`exports/SetTrace-App-Icon-Package.zip`](exports/SetTrace-App-Icon-Package.zip)。

## 设计

延续项目现有图标的哑铃、−18° 倾角，以及“三组完成、一组待练”的进度隐喻。按当前 [Focus A 规范](SetTrace_UI_Design_System_and_Flutter_Spec.md) 使用冷白 `#F5F7F8`、深青绿 `#087F6B`、浅青绿 `#E2F2ED`。采用平面矢量、清晰轮廓和克制圆角。

本次制作通用图标源素材包。项目当前以 Android 为首要目标；本包尚未导出 Android 自适应／单色启动器资源、各密度 mipmap 或商店专用文件，也未替换当前 App、README 或原设计中的图标。

## 文件

| 文件 | 用途 |
| --- | --- |
| `app-icon-package.svg` / `.png` | 无预制圆角的正方形源画布；PNG 为 1024×1024、全不透明 |
| `app-icon-package.preview.svg` / `.preview.png` | 圆角展示预览；圆角外透明，不能直接用来代替平台源画布 |
| `app-icon-package.origin.svg` | 保留的原项目图标，作为来源证据 |
| `layers/01-background.svg` | 正方形冷白背景 |
| `layers/02-dumbbell.svg` | 透明背景上的连续哑铃矢量轮廓 |
| `layers/03-set-progress.svg` | 透明背景上的三枚实心圆和一枚空心环 |
| `tmp/work/spec.json` | 可重新生成的分层规格；所有实际造型均内联在规格中 |
| `tmp/reports/` | 结构、几何、视觉复核及参考叠图／差分证据 |
| `tmp/work/small-size-review.png` | 同一图标在浅深背景上的 128／64／48／32px 实际尺寸检查；不是深色变体 |

## 检查方法

哑铃由原文件的五个圆角矩形做矢量并集，形成单一连续路径。进度点保留原中心和半径，空心环改为带内孔的填充路径，避免把轮廓描边误作材质。

参考比较使用原项目 SVG，仅执行上述三项明确的配色替换，再统一为 1024px、224px 圆角的预览画布。检查并排图、叠图、差分图、局部采样、两个透明前景图层及实际小尺寸。该比较验证几何与指定配色转换，不表示复刻旧薄荷绿色，也不表示 Android 启动器实机验收。

通用包经 `author-icon` 直接生成至交付目录，再执行 `verify --reference` 和前景 `geometry-audit`。空心环的 compound-path 信息提示属于预期内孔。独立视觉复核结论保存在 `tmp/reports/visual-review.json`。

重新生成时，将交付目录与 `tmp/work/spec.json` 的绝对路径传给已安装 `app-icon-gen` 的 `author_icon.mjs --spec ... --out ...`。工作目录中保留了运行时；仅其目录深度检查做了 Windows 路径分隔符兼容修正，仍保留原有安全检查。下载压缩包不包含运行时、依赖或历史暂存文件；它包含源素材、规格和复核证据。
