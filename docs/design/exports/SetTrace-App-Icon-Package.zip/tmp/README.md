# SetTraceFocus

Generated from `D:\000_MyLibrary\100_code\110_Project\5_SetTrace\docs\design\app-icon-package\tmp\work\spec.json`.

- Use `app-icon-package.preview.svg` and `app-icon-package.preview.png` for rounded local review.
- Use `app-icon-package.svg` and `app-icon-package.png` for an unrounded source/app canvas.
- Generic source assets can be adapted to a requested platform after review.

